import os
import sys
import numpy as np            

load_testmap = sys.argv[1]
path_testmap = f"testmap/{load_testmap}"

output_directory = f"results/{load_testmap}"
os.makedirs(output_directory, exist_ok=True)
print(output_directory)


Eigenvector1 = np.loadtxt(f'model/Eigenvector-1.txt')
transformed_add = np.loadtxt(f'results/{load_testmap}/{load_testmap}.txt')
if transformed_add.ndim == 1:
    transformed_add = transformed_add.reshape(1, -1)
Eigenvector1_add_point = transformed_add[:, 0]

list_model = np.loadtxt(f'model/list_model.txt', dtype=str)
classes_m = np.loadtxt(f'model/Mean_data.txt')
Porespy_D = np.loadtxt(f'model/Diff_data.txt')
#Porespy_D = Porespy_D.reshape(1, -1)
Porespy_D = 1/Porespy_D[:,0]

absolute_diff = np.abs(Eigenvector1 - Eigenvector1_add_point)
nearest_index = np.argmin(absolute_diff)
 
print('Dpred:', 1/Porespy_D[nearest_index])
print('parameter:', list_model[nearest_index])

result_path = os.path.join(output_directory, "prediction.txt")
with open(result_path, "w") as f:
    f.write(f"Dpred: {1/Porespy_D[nearest_index]}\n")
    f.write(f"parameter: {list_model[nearest_index]}\n")


################################################################



